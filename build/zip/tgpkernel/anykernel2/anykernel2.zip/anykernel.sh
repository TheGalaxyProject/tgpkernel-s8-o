# AnyKernel2 Ramdisk Mod Script
# osm0sis @ xda-developers
# Portion of S8Port/NFE mods by @kylothow
# Rest done by @djb77

## AnyKernel setup
# begin properties
properties() {
kernel.string=
do.devicecheck=1
do.modules=0
do.cleanup=1
do.cleanuponabort=1
device.name1=dreamlte
device.name2=dream2lte
device.name3=
device.name4=
device.name5=
} # end properties

# shell variables
block=/dev/block/platform/11120000.ufs/by-name/BOOT;
is_slot_device=0;

## AnyKernel methods (DO NOT CHANGE)
# import patching functions/variables - see for reference
. /tmp/anykernel/tools/ak2-core.sh;

## AnyKernel install
ui_print "- Dumping Boot Image";
dump_boot;

# Ramdisk changes for Spectrum
if egrep -q "install=1" "/tmp/aroma/spectrum.prop"; then
	ui_print "- Adding Spectrum";
	replace_file sbin/spa 755 spa;
	replace_file init.spectrum.rc 644 init.spectrum.rc;
	replace_file init.spectrum.sh 644 init.spectrum.sh;
	insert_line init.rc "import init.spectrum.rc" after "import init.services.rc" "import init.spectrum.rc";
fi;

# Ramdisk changes for SELinux Enforcing
if egrep -q "install=1" "/tmp/aroma/selinux.prop"; then
	ui_print "- Enabling SELinux Enforcing Mode";
	replace_string sbin/sysinit.sh "echo \"1\" > /sys/fs/selinux/enforce" "echo \"0\" > /sys/fs/selinux/enforce" "echo \"1\" > /sys/fs/selinux/enforce";
fi;

# end ramdisk changes
ui_print "- Writing Boot Image";
write_boot;

## end install

